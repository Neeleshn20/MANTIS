import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
from io import StringIO

from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
from imblearn.over_sampling import SMOTE

sns.set(style="whitegrid")

# Page Setup
st.set_page_config(layout="wide", page_title="MANTIS AI", page_icon="🛡")
st.markdown("<h1 style='text-align:center;color:#00FFAA;'>MANTIS</h1>", unsafe_allow_html=True)
st.markdown("<h4 style='text-align:center;color:#33FFDD;'>AI-Based Predictive Maintenance and Supply Chain Mapping</h4>", unsafe_allow_html=True)


# Sidebar Navigation
from PIL import Image
import os

# Logo path
logo_path = r"C:\Users\nagan\OneDrive\Desktop\Mantis\App\mantis_logo.png"

# Sidebar logo and navigation
with st.sidebar:
    if os.path.exists(logo_path):
        st.image(logo_path, width=120)  # Adjust width as needed
    else:
        st.warning("⚠️ Logo not found.")

    st.title("🔧 Navigation")
    page = st.radio("Go to", [
        "Home",
        "Predictive Maintenance",
        "Spare Inventory Forecast",
        "Supply Chain Mapping",
        "Anomaly Insights"
    ])

# Load Model
def load_model(model_name):
    model_path = fr"C:\Users\nagan\OneDrive\Desktop\Mantis\models\{model_name}.pkl"
    try:
        return joblib.load(model_path)
    except Exception as e:
        st.error(f"Error loading model: {e}")
        return None

# Home Page
if page == "Home":
    st.subheader("Dashboard Overview")
    st.markdown("Welcome to *MANTIS* – Your AI assistant for *Predictive Maintenance* and *Supply Chain Mapping*.")
    st.markdown("Select a module from the sidebar to get started.")

# Predictive Maintenance
elif page == "Predictive Maintenance":
    st.subheader("Predictive Maintenance AI Engine")
    uploaded_file = st.file_uploader("Upload Equipment Log CSV", type="csv")
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        features = ['Uptime_Hours', 'Environment_Stress', 'Temperature']
        if all(col in df.columns for col in features):
            st.dataframe(df.head())
            clf_model = load_model("equipment_failure_model")
            if clf_model:
                predictions = clf_model.predict(df[features])
                probs = clf_model.predict_proba(df[features])[:, 1]
                df['Failure_Prediction'] = predictions
                df['Failure_Probability'] = probs.round(3)
                joblib.dump(clf_model, r"C:\Users\nagan\OneDrive\Desktop\Mantis\models\equipment_failure_model.pkl")

                st.success("✅ Prediction Completed")
                st.write(df[['Machine_ID', 'Failure_Prediction', 'Failure_Probability']])
                fig, ax = plt.subplots()
                sns.histplot(df['Failure_Probability'], kde=True, color="red", ax=ax)
                ax.set_title("Failure Probability Distribution")
                st.pyplot(fig)
                st.download_button("Download Updated Data", df.to_csv(index=False), "updated_predictions.csv", "text/csv")

# Spare Inventory Forecast
elif page == "Spare Inventory Forecast":
    st.subheader("Spare Inventory Demand Forecasting")
    uploaded_file = st.file_uploader("Upload Spare Inventory CSV", type="csv")
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        st.dataframe(df.head())
        model = load_model("spare_demand_model")
        if model:
            df['Forecasted_Demand_Next_Week'] = model.predict(
    df[['Criticality_Score', 'Lead_Time_Days', 'Current_Stock']]
)
            joblib.dump(model, r"C:\Users\nagan\OneDrive\Desktop\Mantis\models\spare_demand_model.pkl")
            st.success("✅ Forecast Completed")
            
            sorted_df = df.sort_values(by="Forecasted_Demand_Next_Week", ascending=True)

            fig, ax = plt.subplots(figsize=(10, len(sorted_df) // 2))
            sns.barplot(y="Item_Name", x="Forecasted_Demand_Next_Week", data=sorted_df, palette="crest", ax=ax)
            ax.set_title("Spare Part Demand Forecast")
            st.pyplot(fig)

# Supply Chain Mapping
elif page == "Supply Chain Mapping":
    st.subheader("🔗 Supply Chain Mapping AI Engine")

    scm_file = st.file_uploader("Upload Component Mapping CSV", type="csv")

    if scm_file:
        df = pd.read_csv(scm_file)
        st.success("✅ File uploaded successfully!")
        st.markdown("### Select a Component")
        components = df["Component_Name"].unique().tolist()
        selected_component = st.selectbox("Choose a Component", components)

        # Filter for selected component
        component_df = df[df["Component_Name"] == selected_component].copy()

        import networkx as nx
        import matplotlib.pyplot as plt

        # Step 1: Build Graph
        G = nx.DiGraph()
        for _, row in component_df.iterrows():
            tier_label = f"Tier {row['Tier']}"
            supplier = row["Supplier_Name"]
            parent = row["Parent_Org"]
            alternates = row["Alternate_Suppliers"].split(";") if pd.notna(row["Alternate_Suppliers"]) else []

            G.add_node(tier_label, group='tier')
            G.add_node(supplier, group='supplier', risk=row["Risk_Flag"], block=row["Blocklisted"])
            G.add_edge(tier_label, supplier)

            G.add_node(parent, group='parent')
            G.add_edge(supplier, parent)

            for alt in alternates:
                alt = alt.strip()
                if alt:
                    G.add_node(alt, group='alternate')
                    G.add_edge(alt, supplier)  # link alternate to original supplier

        # Step 2: Alternate Supplier Mapping Table
        st.markdown("### 🔁 Alternate Supplier Mapping Table")
        rows = []
        for _, row in component_df.iterrows():
            original_supplier = row["Supplier_Name"]
            tier = row["Tier"]
            risk = row["Risk_Flag"]
            blocklisted = row["Blocklisted"]
            alt_suppliers = row["Alternate_Suppliers"]
            if pd.notna(alt_suppliers):
                for alt in alt_suppliers.split(";"):
                    alt = alt.strip()
                    if alt:
                        rows.append({
                            "Alternate Supplier": alt,
                            "Replacing Supplier": original_supplier,
                            "Tier": tier,
                            "Risk Level": risk,
                            "Blocklisted": blocklisted
                        })

        alt_df = pd.DataFrame(rows)
        if not alt_df.empty:
            st.dataframe(alt_df)
            csv_data = alt_df.to_csv(index=False).encode('utf-8')
            st.download_button("📥 Download Mapping Table", csv_data, "alternate_supplier_mapping.csv", "text/csv", key="download_mapping_btn")
        else:
            st.info("No alternate suppliers found for this component.")

        # Step 3: Supplier Risk Index (from notebook)
        st.markdown("### 🔒 Supplier Risk Index (for selected component)")

        risk_weights = {'Low': 1, 'Medium': 2, 'High': 3}
        dependency_weights = {'Low': 1, 'Medium': 2, 'High': 3}
        blocklist_penalty = 2

        component_df['Risk_Score'] = component_df['Risk_Flag'].map(risk_weights)
        component_df['Blocklist_Score'] = component_df['Blocklisted'].apply(lambda x: blocklist_penalty if x == 'Yes' else 0)
        component_df['Dependency_Score'] = component_df['Dependency_Level'].map(dependency_weights)

        component_df['Supplier_Risk_Index'] = (
            0.5 * component_df['Risk_Score'] +
            0.3 * component_df['Blocklist_Score'] +
            0.2 * component_df['Dependency_Score']
        )

        top_risk_df = component_df[['Supplier_Name', 'Risk_Flag', 'Blocklisted', 'Dependency_Level', 'Supplier_Risk_Index']].sort_values(by="Supplier_Risk_Index", ascending=False).drop_duplicates("Supplier_Name")
        st.dataframe(top_risk_df.head(5), use_container_width=True)

        # Optional Risk Bar Chart
        st.markdown("### 📊 Risk Index Chart")
        try:
            import seaborn as sns
            fig, ax = plt.subplots(figsize=(8, 4))
            sns.barplot(data=top_risk_df.head(5), x='Supplier_Risk_Index', y='Supplier_Name', palette='coolwarm', ax=ax)
            ax.set_title("Top 5 Risky Suppliers")
            ax.set_xlabel("Risk Index")
            ax.set_ylabel("Supplier")
            st.pyplot(fig)
        except:
            st.info("Unable to generate plot.")

        # Step 4: Network Graph
        st.markdown("### 📡 Supply Chain Graph (Tiered Layout)")
        all_suppliers = list(component_df["Supplier_Name"].unique())
        all_parents = list(component_df["Parent_Org"].unique())
        all_alternates = []
        component_df["Alternate_Suppliers"] = component_df["Alternate_Suppliers"].fillna("")
        for alt in component_df["Alternate_Suppliers"]:
            all_alternates.extend([a.strip() for a in alt.split(";") if a.strip()])
        tier_dict = component_df.groupby("Tier")["Supplier_Name"].unique().to_dict()

        shells = [[f"Tier {t}"] for t in sorted(tier_dict.keys())]
        shells.append(["Alternates"])
        shells.extend([tier_dict[t] for t in sorted(tier_dict.keys())])
        shells.append(all_parents)
        shells.append(all_alternates)

        pos = nx.shell_layout(G, shells)

        color_map = []
        for node in G.nodes():
            group = G.nodes[node].get("group", "")
            if group == 'tier':
                color_map.append("skyblue")
            elif group == 'supplier':
                risk = G.nodes[node].get("risk", "Low")
                if risk == "High":
                    color_map.append("red")
                elif risk == "Medium":
                    color_map.append("orange")
                else:
                    color_map.append("green")
            elif group == 'parent':
                color_map.append("gray")
            elif group == 'alternate':
                color_map.append("purple")
            else:
                color_map.append("lightgray")

        fig, ax = plt.subplots(figsize=(16, 10))
        nx.draw_networkx(
            G, pos,
            node_color=color_map,
            with_labels=True,
            arrows=True,
            node_size=1000,
            font_size=7,
            edge_color='gray'
        )
        plt.title("Supply Chain Network", fontsize=14)
        st.pyplot(fig)

        # List Alternates
        st.markdown("### Alternate Suppliers")
        st.write(", ".join(sorted(set(all_alternates))) if all_alternates else "No alternates listed.")

# Anomaly Insights
elif page == "Anomaly Insights":
    st.subheader("⚠️ Anomaly Detection Outputs")

    st.markdown("Upload or view pre-generated anomaly detection results.")
    
    # Options for anomaly datasets
    options = {
        "Equipment Anomalies": r"C:\Users\nagan\OneDrive\Desktop\Mantis\anomaly_outputs\equipment_anomalies.csv",
        "Inventory Anomalies": r"C:\Users\nagan\OneDrive\Desktop\Mantis\anomaly_outputs\spare_inventory_anomalies.csv",
        "RouteMap Anomalies": r"C:\Users\nagan\OneDrive\Desktop\Mantis\anomaly_outputs\route_map_anomalies.csv"
    }

    selected_file = st.selectbox("Choose an Anomaly Report", list(options.keys()))
    file_path = options[selected_file]

    try:
        df = pd.read_csv(file_path)
        st.success(f"✅ Loaded {selected_file}")
        st.dataframe(df)

        # Basic Plot if numeric anomaly score exists
        numeric_cols = df.select_dtypes(include='number').columns.tolist()
        if numeric_cols:
            st.markdown("### 📊 Anomaly Score Distribution")
            fig, ax = plt.subplots()
            sns.histplot(df[numeric_cols[0]], kde=True, color="crimson", ax=ax)
            ax.set_title(f"{numeric_cols[0]} Distribution")
            st.pyplot(fig)
        else:
            st.info("No numeric anomaly score column found to plot.")

        # Download button
        csv = df.to_csv(index=False).encode('utf-8')
        st.download_button(f"📥 Download {selected_file}", csv, f"{selected_file.lower().replace(' ', '_')}.csv", "text/csv")

    except Exception as e:
        st.error(f"Failed to load anomaly file: {e}")

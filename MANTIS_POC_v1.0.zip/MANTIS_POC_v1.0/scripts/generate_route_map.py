import pandas as pd
import numpy as np
import random

np.random.seed(42)
random.seed(42)

# Define possible nodes
nodes = ['Base_A', 'Base_B', 'Depot_1', 'Depot_2', 'Field_Camp_X', 'Field_Camp_Y', 'Port_Alpha', 'Port_Beta', 'HQ_Zulu']
terrains = ['Plain', 'Hill', 'Desert', 'Forest', 'Urban']
weather_conditions = ['Clear', 'Rainy', 'Snow', 'Storm']
blockage_statuses = ['Open', 'Partially Blocked', 'Fully Blocked']
risk_levels = ['Low', 'Medium', 'High']

data = []
route_id = 1

# Generate around 400 routes
for _ in range(400):
    src, dest = random.sample(nodes, 2)

    distance_km = np.random.randint(30, 1000)
    terrain = random.choice(terrains)
    weather = random.choice(weather_conditions)
    enemy_threat = round(np.clip(np.random.normal(0.4, 0.3), 0, 1), 2)

    # Delay logic: dependent on terrain, weather, and enemy threat
    base_delay = distance_km / 60  # Assume avg speed = 60 km/h
    terrain_delay_factor = {'Plain': 1.0, 'Urban': 1.1, 'Forest': 1.3, 'Hill': 1.5, 'Desert': 1.6}[terrain]
    weather_delay_factor = {'Clear': 1.0, 'Rainy': 1.2, 'Snow': 1.4, 'Storm': 2.0}[weather]
    threat_delay_factor = 1 + enemy_threat * 1.5

    avg_delay = round(base_delay * terrain_delay_factor * weather_delay_factor * threat_delay_factor, 2)

    # Blockage logic
    blockage = (
        "Fully Blocked" if enemy_threat > 0.8 or weather == "Storm"
        else "Partially Blocked" if enemy_threat > 0.5 or weather in ["Snow", "Rainy"]
        else "Open"
    )

    # Risk logic
    risk_score = enemy_threat * 0.6 + (1 if terrain in ['Hill', 'Forest', 'Desert'] else 0) * 0.2 + \
                 (1 if blockage != 'Open' else 0) * 0.2
    if risk_score >= 0.75:
        risk = 'High'
    elif risk_score >= 0.4:
        risk = 'Medium'
    else:
        risk = 'Low'

    data.append({
        'Route_ID': f"R{route_id:04d}",
        'Source': src,
        'Destination': dest,
        'Distance_km': distance_km,
        'Terrain': terrain,
        'Weather': weather,
        'Enemy_Threat_Score': enemy_threat,
        'Avg_Delay_hrs': avg_delay,
        'Blockage_Status': blockage,
        'Risk_Level': risk
    })
    route_id += 1

# Save as CSV
df_routes = pd.DataFrame(data)
df_routes.to_csv("route_map.csv", index=False)

print("✅ Route map dataset with 400+ records saved as 'route_map.csv'")

import pandas as pd
import numpy as np
import random

# Set seed for reproducibility
np.random.seed(42)
random.seed(42)

# Define parameters
num_items = 300
item_names = [f"Part_{i+1}" for i in range(num_items)]
categories = ['Electrical', 'Mechanical', 'Hydraulic', 'Electronic', 'Sensor']
suppliers = ['AlphaCorp', 'BetaParts', 'GammaSupplies', 'DeltaTech', 'EpsilonEnterprises']
locations = ['Base_A', 'Base_B', 'Base_C', 'Field_X', 'Depot_Y']

data = []

for name in item_names:
    category = random.choice(categories)
    supplier = random.choice(suppliers)
    location = random.choice(locations)

    # Assign criticality score (0 to 1), higher means more critical
    criticality = round(np.clip(np.random.normal(loc=0.6 if category == 'Sensor' else 0.4, scale=0.2), 0, 1), 2)

    # Usage rate correlates with criticality + randomness
    daily_use_rate = max(0.1, np.random.poisson(lam=3 + 5 * criticality))

    # Stock inversely related to criticality (if critical, keep fewer)
    current_stock = max(10, int(np.random.normal(100 - 50 * criticality, 20)))

    # Lead time depends on supplier
    lead_time_days = int(np.clip(np.random.normal(loc=10 + 5 * suppliers.index(supplier), scale=2), 3, 30))

    # Reorder threshold logic
    reorder_threshold = int(current_stock * (0.4 if criticality > 0.6 else 0.2))

    # Add slight randomness to represent diversity in data
    unit_cost = round(np.random.uniform(100, 1000) * (1 + criticality), 2)

    data.append({
        "Item_ID": f"I{name[-3:]}",
        "Item_Name": name,
        "Category": category,
        "Supplier": supplier,
        "Location": location,
        "Criticality_Score": criticality,
        "Daily_Use_Rate": daily_use_rate,
        "Current_Stock": current_stock,
        "Lead_Time_Days": lead_time_days,
        "Reorder_Threshold": reorder_threshold,
        "Unit_Cost": unit_cost
    })

# Create DataFrame
spare_inventory_df = pd.DataFrame(data)

# Save CSV
spare_inventory_df.to_csv("spare_inventory.csv", index=False)

print("✅ Enhanced spare inventory data generated and saved as 'spare_inventory.csv'")

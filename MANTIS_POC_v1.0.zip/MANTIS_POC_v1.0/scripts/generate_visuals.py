import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Ensure output folder exists
output_dir = r"C:\Users\nagan\OneDrive\Desktop\Mantis\visuals"
os.makedirs(output_dir, exist_ok=True)

# ---------- EQUIPMENT LOGS VISUALS ----------
equipment = pd.read_csv(r"C:\Users\nagan\OneDrive\Desktop\Mantis\equipment_logs.csv")

# 1. Uptime distribution
plt.figure(figsize=(8, 4))
sns.histplot(equipment['Uptime_Hours'], bins=30, kde=True)
plt.title("Equipment Uptime Distribution")
plt.xlabel("Uptime (Hours)")
plt.tight_layout()
plt.savefig(f"{output_dir}/uptime_distribution.png")

# 2. Failures per Machine
plt.figure(figsize=(10, 5))
sns.countplot(data=equipment, x='Machine_ID', hue='Failure')
plt.title("Failure Frequency per Machine")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(f"{output_dir}/failures_by_machine.png")

# 3. Environment Stress vs Failure
plt.figure(figsize=(6, 5))
sns.boxplot(x='Failure', y='Environment_Stress', data=equipment)
plt.title("Environment Stress vs Failure")
plt.xlabel("Failure (1=Yes, 0=No)")
plt.tight_layout()
plt.savefig(f"{output_dir}/envstress_vs_failure.png")

# ---------- SPARE INVENTORY VISUALS ----------
spares = pd.read_csv(r"C:\Users\nagan\OneDrive\Desktop\Mantis\spare_inventory.csv")

# 4. Current stock per spare
top_spares = spares.sort_values(by="Current_Stock", ascending=False).head(20)
plt.figure(figsize=(10, 5))
sns.barplot(data=top_spares, x="Item_Name", y="Current_Stock")
plt.title("Top 20 Spare Parts by Stock Level")
plt.xticks(rotation=90)
plt.tight_layout()
plt.savefig(f"{output_dir}/spares_stock_levels.png")

# 5. Daily Use Rate vs Stock (scatter)
plt.figure(figsize=(6, 5))
sns.scatterplot(data=spares, x="Daily_Use_Rate", y="Current_Stock", hue="Lead_Time_Days", palette="coolwarm")
plt.title("Daily Usage vs Current Stock")
plt.tight_layout()
plt.savefig(f"{output_dir}/usage_vs_stock.png")

# ---------- ROUTE MAP VISUALS ----------
routes = pd.read_csv(r"C:\Users\nagan\OneDrive\Desktop\Mantis\route_map.csv")

# 6. Delay distribution
plt.figure(figsize=(8, 4))
sns.histplot(routes['Avg_Delay_hrs'], bins=20, kde=True)
plt.title("Distribution of Route Delays")
plt.xlabel("Average Delay (hrs)")
plt.tight_layout()
plt.savefig(f"{output_dir}/delay_distribution.png")

# 7. Risk Level Pie Chart
risk_counts = routes['Risk_Level'].value_counts()
plt.figure(figsize=(6, 6))
plt.pie(risk_counts, labels=risk_counts.index, autopct="%1.1f%%", startangle=90)
plt.title("Route Risk Level Distribution")
plt.savefig(f"{output_dir}/risk_level_pie.png")

# 8. Blocked vs Open routes
plt.figure(figsize=(6, 4))
sns.countplot(data=routes, x='Blockage_Status')
plt.title("Route Blockage Status")
plt.tight_layout()
plt.savefig(f"{output_dir}/route_blockages.png")

plt.figure(figsize=(8, 6))
sns.heatmap(equipment.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Feature Correlation Heatmap - Equipment Logs")
plt.tight_layout()
plt.savefig(f"{output_dir}/equipment_corr_heatmap.png")

# Time series of failures
if 'Timestamp' in equipment.columns:
    equipment['Timestamp'] = pd.to_datetime(equipment['Timestamp'])
    failures_over_time = equipment[equipment['Failure'] == 1].groupby(pd.Grouper(key='Timestamp', freq='D')).size()

    plt.figure(figsize=(10, 4))
    failures_over_time.plot()
    plt.title("Daily Failure Count Over Time")
    plt.ylabel("Failures")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/failures_over_time.png")

plt.figure(figsize=(8, 6))
sns.scatterplot(data=routes, x="Enemy_Threat_Score", y="Avg_Delay_hrs", hue="Risk_Level", size="Distance_km", palette="Set1", alpha=0.7)
plt.title("Route Threat vs Delay (Bubble = Distance)")
plt.tight_layout()
plt.savefig(f"{output_dir}/threat_vs_delay_risk.png")

# Filter for high-usage & low-stock items (potential supply risk)
anomalous_spares = spares[(spares['Daily_Use_Rate'] > spares['Daily_Use_Rate'].quantile(0.75)) &
                          (spares['Current_Stock'] < spares['Current_Stock'].quantile(0.25))]

plt.figure(figsize=(10, 4))
sns.barplot(data=anomalous_spares, x="Item_Name", y="Current_Stock", palette="Reds_r")
plt.title("Anomalous Spares: High Use, Low Stock")
plt.xticks(rotation=90)
plt.tight_layout()
plt.savefig(f"{output_dir}/anomalous_spares.png")


print("✅ All visualizations saved in 'visuals/' folder.")

import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Load data
equipment = pd.read_csv(r"C:\Users\nagan\OneDrive\Desktop\Mantis\data\equipment_logs.csv")
output_dir = r"C:\Users\nagan\OneDrive\Desktop\Mantis\anomaly_outputs"
os.makedirs(output_dir, exist_ok=True)

# Features to use
features = ['Uptime_Hours', 'Environment_Stress', 'Temperature']
X = equipment[features].dropna()

# Isolation Forest
model = IsolationForest(n_estimators=100, contamination=0.05, random_state=42)
equipment['Anomaly_Score'] = model.fit_predict(X)
equipment['Anomaly'] = equipment['Anomaly_Score'].apply(lambda x: 1 if x == -1 else 0)

# Save anomaly-labeled dataset
equipment.to_csv(f"{output_dir}/equipment_anomalies.csv", index=False)

# Plot anomaly distribution
plt.figure(figsize=(8, 5))
sns.scatterplot(data=equipment, x='Uptime_Hours', y='Environment_Stress', hue='Anomaly', palette='Set1')
plt.title("Equipment Anomalies (Isolation Forest)")
plt.tight_layout()
plt.savefig(f"{output_dir}/equipment_anomaly_plot.png")

print("✅ Equipment anomaly detection complete.")

# Load spare inventory data
spares = pd.read_csv(r"C:\Users\nagan\OneDrive\Desktop\Mantis\data\spare_inventory.csv")

# Rule-based anomaly conditions
spares['Anomaly'] = (
    (spares['Current_Stock'] < spares['Current_Stock'].quantile(0.2)) &
    (spares['Daily_Use_Rate'] > spares['Daily_Use_Rate'].quantile(0.8)) &
    (spares['Lead_Time_Days'] > 10)
).astype(int)

# Save output
spares.to_csv(f"{output_dir}/spare_inventory_anomalies.csv", index=False)

# Plot
plt.figure(figsize=(8, 5))
sns.scatterplot(data=spares, x='Daily_Use_Rate', y='Current_Stock', hue='Anomaly', palette='coolwarm')
plt.title("Spare Inventory Anomalies")
plt.tight_layout()
plt.savefig(f"{output_dir}/spare_inventory_anomaly_plot.png")

print("✅ Spare inventory anomaly detection complete.")

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN

# Load route map
routes = pd.read_csv(r"C:\Users\nagan\OneDrive\Desktop\Mantis\data\route_map.csv")

# Features to cluster on
features = ['Avg_Delay_hrs', 'Enemy_Threat_Score', 'Distance_km']
X = routes[features].dropna()
X_scaled = StandardScaler().fit_transform(X)

# DBSCAN
dbscan = DBSCAN(eps=1.2, min_samples=5)
routes['Cluster'] = dbscan.fit_predict(X_scaled)
routes['Anomaly'] = (routes['Cluster'] == -1).astype(int)

# Save output
routes.to_csv(f"{output_dir}/route_map_anomalies.csv", index=False)

# Visual
plt.figure(figsize=(8, 5))
sns.scatterplot(data=routes, x='Avg_Delay_hrs', y='Enemy_Threat_Score', hue='Anomaly', palette='Set2')
plt.title("Route Map Anomalies (DBSCAN)")
plt.tight_layout()
plt.savefig(f"{output_dir}/route_map_anomaly_plot.png")

print("✅ Route map anomaly detection complete.")

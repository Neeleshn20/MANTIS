import pandas as pd
import numpy as np
import random

np.random.seed(42)

num_records = 400
machine_ids = [f'MAC_{i:03d}' for i in range(1, 21)]  # 20 unique machines

data = []

for _ in range(num_records):
    machine = random.choice(machine_ids)
    uptime = np.random.normal(1000, 300)
    uptime = np.clip(uptime, 100, 5000)
    
    stress = np.random.normal(50, 15)
    stress = np.clip(stress, 10, 100)

    temperature = np.random.normal(40, 10) + (stress * 0.1)
    vibration = np.random.normal(0.3, 0.15) + (stress * 0.005)

    # Failure probability increases with stress, uptime, and temp
    prob_failure = (
        0.05
        + 0.002 * ((uptime - 1000) / 100)
        + 0.01 * ((stress - 50) / 10)
        + 0.01 * ((temperature - 40) / 10)
    )
    prob_failure = np.clip(prob_failure, 0, 1)
    failure = np.random.rand() < prob_failure

    data.append({
        'Machine_ID': machine,
        'Uptime_Hours': round(uptime, 2),
        'Environment_Stress': round(stress, 2),
        'Temperature': round(temperature, 2),
        'Vibration': round(vibration, 3),
        'Failure': int(failure)
    })

df = pd.DataFrame(data)

# Inject structured outliers (5 random severe stress entries)
for i in np.random.choice(df.index, size=5, replace=False):
    df.at[i, 'Environment_Stress'] = 95 + np.random.rand() * 5
    df.at[i, 'Temperature'] += 15
    df.at[i, 'Vibration'] += 0.5
    df.at[i, 'Failure'] = 1

df.to_csv("equipment_logs.csv", index=False)
print("✅ Enhanced equipment log dataset created.")
